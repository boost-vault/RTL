#include "pch.hpp"

#include "perfmeter.hpp"

int Perfmeter::default_counter = 0;
int Perfmeter::copy_counter = 0;
int Perfmeter::comp_counter = 0;
int Perfmeter::assign_counter = 0;
